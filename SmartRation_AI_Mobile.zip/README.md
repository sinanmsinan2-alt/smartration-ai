# SmartRation AI — Mobile Edition

A phone-first Streamlit MVP for the ZEPHYR 2026 hackathon.

## What it demonstrates

Predict → Prepare → Buy → Risk → Act → Learn

- Demand forecast
- Preparation/BOM planning
- Procurement recommendation
- Expiry / slow-moving risk
- Money-at-risk
- What-if simulation
- Human approval
- Actual-vs-predicted learning log
- Mobile-first layout with touch-friendly controls

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

Open the local Streamlit address from your phone if the phone and computer are on the same network.

## Public deployment

Deploy `app.py` and `requirements.txt` from a GitHub repository using Streamlit Community Cloud.

The deployed app opens directly in a phone browser and does not require an Android APK for the hackathon demo.

## Important

The included numbers are illustrative demo data. For a production system, connect real sales/consumption, inventory, recipe/BOM, purchase, supplier, expiry and outcome data.
