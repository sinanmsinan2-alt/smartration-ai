
import math
import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="SmartRation AI",
    page_icon="🍱",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# -----------------------------
# SmartRation AI — Mobile Edition
# Predict → Prepare → Buy → Risk → Act → Learn
# -----------------------------

st.markdown("""
<style>
/* Phone-first UI */
.block-container { max-width: 760px; padding: 0.7rem 0.85rem 5rem 0.85rem; }
header { visibility: hidden; height: 0; }
h1 { font-size: 1.8rem !important; margin-bottom: .15rem !important; }
h2 { font-size: 1.35rem !important; }
h3 { font-size: 1.1rem !important; }
p, label, .stMarkdown { font-size: .96rem; }
[data-testid="stMetric"] {
    padding: .65rem .7rem;
    border: 1px solid rgba(128,128,128,.22);
    border-radius: 14px;
    min-height: 92px;
}
[data-testid="stMetricLabel"] { font-size: .78rem !important; }
[data-testid="stMetricValue"] { font-size: 1.35rem !important; }
.stButton > button {
    min-height: 48px;
    border-radius: 12px;
    font-weight: 700;
}
.stSelectbox > div > div, .stSlider > div { border-radius: 12px; }
div[data-testid="stDataFrame"] { font-size: .78rem; }
.mobile-card {
    padding: .85rem;
    border: 1px solid rgba(128,128,128,.22);
    border-radius: 16px;
    margin: .45rem 0;
}
.action-card {
    padding: .8rem;
    border-left: 5px solid currentColor;
    border-radius: 12px;
    background: rgba(128,128,128,.08);
    margin: .45rem 0;
}
.small-muted { opacity: .72; font-size: .82rem; }
@media (max-width: 600px) {
    .block-container { padding-left: .65rem; padding-right: .65rem; }
    [data-testid="stHorizontalBlock"] { gap: .45rem; }
}
</style>
""", unsafe_allow_html=True)

RECIPES = {
    "Rice": {"unit":"kg","per_meal":0.055,"price":55},
    "Vegetables": {"unit":"kg","per_meal":0.0735,"price":70},
    "Curd": {"unit":"kg","per_meal":0.0506,"price":85},
    "Oil": {"unit":"L","per_meal":0.0098,"price":135},
}
DEFAULT_STOCK = {"Rice":20.0,"Vegetables":14.0,"Curd":12.0,"Oil":3.0}
DEFAULT_INCOMING = {"Rice":8.0,"Vegetables":5.0,"Curd":0.0,"Oil":2.0}
DEFAULT_EXPIRY_DAYS = {"Rice":30,"Vegetables":3,"Curd":2,"Oil":70}
PACK = {"Rice":5,"Vegetables":5,"Curd":2,"Oil":1}

def round_up_pack(qty, pack):
    return math.ceil(max(0, qty)/pack)*pack if pack else max(0, qty)

def forecast(attendance, weekend, event, trend, recent_actuals):
    base = max(1, attendance * .92)
    weekend_factor = 1.07 if weekend else 1.0
    event_factor = 1.12 if event else 1.0
    trend_factor = 1 + trend/100
    history = np.array(recent_actuals, dtype=float)
    hist_factor = np.mean(history[-3:])/np.mean(history) if len(history)>=3 and np.mean(history) else 1.0
    demand = base * weekend_factor * event_factor * trend_factor * hist_factor
    confidence = "HIGH" if len(history)>=7 and np.std(history)/np.mean(history)<.12 else "MEDIUM"
    return int(round(demand)), confidence

def decision_chain(demand, buffer_pct, stock, incoming, expiry_days):
    prepared = int(math.ceil(demand*(1+buffer_pct/100)))
    rows, total_purchase, total_risk = [], 0.0, 0.0
    for item, spec in RECIPES.items():
        required = prepared * spec["per_meal"]
        usable, inbound = stock[item], incoming[item]
        need = max(0, required - usable - inbound)
        purchase = round_up_pack(need, PACK[item])
        leftover = max(0, usable-required)
        expiry_risk = leftover*spec["price"] if expiry_days[item] <= 3 and leftover > 0 else 0
        slow_risk = leftover*spec["price"]*.25 if leftover > 0 else 0
        money_risk = expiry_risk + slow_risk
        if expiry_days[item] <= 2 and leftover > 0:
            action = "USE FIRST"
        elif purchase > 0:
            action = "BUY NOW"
        elif leftover > required*.35:
            action = "DO NOT BUY"
        else:
            action = "MONITOR"
        total_purchase += purchase*spec["price"]
        total_risk += money_risk
        rows.append({
            "Item": item, "Required": round(required,2),
            "Stock": round(usable,2), "Incoming": round(inbound,2),
            "Purchase": round(purchase,2), "Expiry": expiry_days[item],
            "Risk": round(money_risk,0), "Action": action
        })
    return prepared, pd.DataFrame(rows), total_purchase, total_risk

if "history" not in st.session_state: st.session_state.history = []
if "approved" not in st.session_state: st.session_state.approved = []

# Header
st.title("🍱 SmartRation AI")
st.caption("Mobile Decision Intelligence • Predict → Decide → Act → Learn")

# Mobile controls
with st.expander("⚙️ Scenario controls", expanded=False):
    attendance = st.slider("Expected attendance", 100, 1000, 540, 10)
    weekend = st.toggle("Weekend", True)
    event = st.toggle("College event", True)
    trend = st.slider("Recent demand trend (%)", -20, 30, 3)
    buffer_pct = st.slider("Preparation buffer (%)", 0, 15, 3)
    st.markdown("**What-if**")
    attendance_delta = st.slider("Attendance change (%)", -30, 40, 0)
    supplier_delay = st.toggle("Supplier delayed")
    extra_stock = st.slider("Extra usable stock", 0, 50, 0)

recent = [480,495,510,505,470,500,515,490,505,520]
scenario_attendance = attendance*(1+attendance_delta/100)
demand, confidence = forecast(scenario_attendance, weekend, event, trend, recent)

stock = DEFAULT_STOCK.copy()
incoming = DEFAULT_INCOMING.copy()
if supplier_delay:
    incoming = {k:v*.35 for k,v in incoming.items()}
for k in stock:
    stock[k] += extra_stock/len(stock)

prepared, plan, purchase_value, risk_value = decision_chain(
    demand, buffer_pct, stock, incoming, DEFAULT_EXPIRY_DAYS
)
open_actions = int((plan["Action"] != "MONITOR").sum())

# Hero summary
st.markdown(
    f'<div class="mobile-card"><b>Today's AI decision</b><br>'
    f'<span class="small-muted">Forecast confidence: {confidence}</span><br>'
    f'<strong>Prepare {prepared:,} meals</strong> • Buy ₹{purchase_value:,.0f} • Risk ₹{risk_value:,.0f}</div>',
    unsafe_allow_html=True
)

# Compact KPI grid
c1,c2 = st.columns(2)
c1.metric("Expected meals", f"{demand:,}")
c2.metric("Open actions", str(open_actions))
c3,c4 = st.columns(2)
c3.metric("Buy value", f"₹{purchase_value:,.0f}")
c4.metric("Money at risk", f"₹{risk_value:,.0f}")

# Mobile navigation
page = st.selectbox(
    "📱 Open",
    ["🧠 Decision Center","📦 Prepare & Buy","⚠️ Risk","🔮 What-if","✅ Approve & Learn"],
    label_visibility="visible"
)

if page == "🧠 Decision Center":
    st.subheader("SmartRation Decision Graph")
    st.markdown("**DEMAND → PREPARE → BUY → RISK → ACTION → LEARN**")
    reason_bits = [
        "weekend" if weekend else "weekday",
        "college event" if event else "no event",
        f"{trend:+d}% recent trend"
    ]
    st.info(f"Forecast is **{demand:,} meals** from {', '.join(reason_bits)}.")

    st.subheader("🔥 Action Center")
    urgent = []
    for _, r in plan.iterrows():
        if r.Action == "BUY NOW":
            urgent.append(f"🛒 **BUY** {r.Purchase:g} {RECIPES[r.Item]['unit']} {r.Item}")
        elif r.Action == "USE FIRST":
            urgent.append(f"⏳ **USE FIRST** {r.Item} — expiry is approaching")
        elif r.Action == "DO NOT BUY":
            urgent.append(f"🛑 **DO NOT BUY** {r.Item} — stock is sufficient")
    for action in urgent or ["✅ No urgent action. Monitor the plan."]:
        st.markdown(f'<div class="action-card">{action}</div>', unsafe_allow_html=True)

    st.subheader("Decision details")
    st.dataframe(
        plan[["Item","Purchase","Risk","Action","Expiry"]],
        use_container_width=True, hide_index=True
    )

elif page == "📦 Prepare & Buy":
    st.subheader("Preparation Intelligence")
    st.info(f"Demand {demand:,} × BOM × {buffer_pct}% buffer → **{prepared:,} meals planned**")
    st.dataframe(
        plan[["Item","Required","Stock","Incoming","Purchase"]],
        use_container_width=True, hide_index=True
    )
    st.subheader("Procurement rule")
    st.code("Purchase = Requirement − Usable Stock − Incoming")
    st.caption("Pack sizes are rounded up automatically.")

elif page == "⚠️ Risk":
    st.subheader("Inventory Risk")
    st.metric("Total money at risk", f"₹{risk_value:,.0f}")
    for _, r in plan.iterrows():
        if r.Risk > 0:
            st.markdown(
                f'<div class="action-card">⚠️ <b>{r.Item}</b> — ₹{r.Risk:,.0f} exposure • {r.Expiry} days to expiry</div>',
                unsafe_allow_html=True
            )
    st.dataframe(
        plan[["Item","Expiry","Risk","Action"]],
        use_container_width=True, hide_index=True
    )
    st.caption("Food-safety rules override AI recommendations. Expiry is not an automatic discount signal.")

elif page == "🔮 What-if":
    st.subheader("What-if Simulator")
    alt_demand, alt_conf = forecast(scenario_attendance, weekend, event, trend, recent)
    alt_prepared, alt_plan, alt_purchase, alt_risk = decision_chain(
        alt_demand, buffer_pct, stock, incoming, DEFAULT_EXPIRY_DAYS
    )
    a,b = st.columns(2)
    a.metric("Forecast", f"{alt_demand:,}", f"{alt_demand-demand:+d}")
    b.metric("Buy value", f"₹{alt_purchase:,.0f}", f"₹{alt_purchase-purchase_value:+,.0f}")
    st.metric("Risk", f"₹{alt_risk:,.0f}", f"₹{alt_risk-risk_value:+,.0f}")
    if supplier_delay:
        st.warning("Supplier delay is ON — incoming stock has been reduced to 35% for this simulation.")
    st.dataframe(
        alt_plan[["Item","Purchase","Risk","Action"]],
        use_container_width=True, hide_index=True
    )

elif page == "✅ Approve & Learn":
    st.subheader("Human Approval")
    recommendation = "Maintain current preparation plan"
    reason = "Demand signals are balanced."
    if demand < attendance*.88:
        recommendation = "Reduce tomorrow's preparation"
        reason = "Recent demand is below the attendance-adjusted baseline."
    elif demand > attendance*.98:
        recommendation = "Increase tomorrow's preparation"
        reason = "Attendance, event and trend signals indicate higher demand."

    st.success(f"**AI recommendation:** {recommendation}")
    st.write(f"**Why:** {reason}")
    st.write(f"**Confidence:** {confidence.title()}")

    x,y = st.columns(2)
    if x.button("✓ APPROVE", use_container_width=True):
        st.session_state.approved.append({
            "Decision": recommendation, "Forecast": demand, "Status":"Approved"
        })
        st.success("Approved and logged.")
    if y.button("✎ EDIT / REJECT", use_container_width=True):
        st.session_state.approved.append({
            "Decision": recommendation, "Forecast": demand, "Status":"Operator review"
        })
        st.info("Operator review logged.")

    if st.session_state.approved:
        st.subheader("Approval history")
        st.dataframe(pd.DataFrame(st.session_state.approved), use_container_width=True, hide_index=True)

    st.divider()
    st.subheader("🧠 Learning Loop")
    actual = st.number_input(
        "Actual meals served", min_value=0, max_value=2000,
        value=max(0,demand-30), step=10
    )
    if st.button("Record actual outcome", use_container_width=True):
        error = actual-demand
        st.session_state.history.append({
            "Predicted": demand, "Actual": actual, "Error": error,
            "Context": f"weekend={weekend}, event={event}"
        })
        st.success(f"Outcome recorded. Forecast error = {error:+d} meals.")
    if st.session_state.history:
        st.dataframe(pd.DataFrame(st.session_state.history), use_container_width=True, hide_index=True)

st.divider()
st.caption("SmartRation AI • ZEPHYR 2026 • Prototype/demo data")
